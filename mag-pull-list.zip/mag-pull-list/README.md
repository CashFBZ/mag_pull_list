# MAG ORDERS PULL LIST — Deployment Guide

## Option A: Deploy to Netlify (FREE — recommended, 2 minutes)

1. Go to https://app.netlify.com/drop
2. Drag the entire `mag-pull-list` folder onto the page
3. Done! You'll get a live URL like `https://random-name.netlify.app`
4. Bookmark it or add to your phone's home screen

To get a custom URL (optional):
- Sign up for a free Netlify account
- Go to Site Settings > Domain Management > Change site name
- Pick something like `mag-pull-list.netlify.app`

## Option B: Open directly on your computer

1. Double-click `index.html` — it opens in your browser
2. Saving works via localStorage (your progress stays as long as you use the same browser)

## Adding to your phone's home screen (works like an app)

### iPhone:
1. Open the site in Safari
2. Tap the Share button (square with arrow)
3. Tap "Add to Home Screen"
4. Name it "MAG Pull" and tap Add

### Android:
1. Open the site in Chrome
2. Tap the three-dot menu
3. Tap "Add to Home Screen" or "Install app"

## Features
- Checklist with progress tracking
- Sort by Category or by Invoice
- Filter: All / Remaining / Pulled
- Add new items manually
- Delete items you don't need
- Progress saves automatically (localStorage)
- Works offline once loaded
- Mobile-friendly design
